namespace salesApi.Models
{
    public class Customer
    {
        public int id { get; set; }
        public string customerId { get; set; }
        public string customerName { get; set; }
        public string customerAddress { get; set; }
        public string emailAddress { get; set; }
    }
}